// compat with metro without package exports
Object.assign(module.exports, require('../dist/cjs/v3.native.js'))
