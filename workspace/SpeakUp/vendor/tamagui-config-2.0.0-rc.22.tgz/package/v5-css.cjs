Object.assign(module.exports, require('./dist/cjs/v5-css.cjs'))
