// compat with tamagui static compiler
Object.assign(module.exports, require('../dist/cjs/linear-gradient.cjs'))
